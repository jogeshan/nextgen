import { Link } from "react-router-dom";
import { ArrowRight, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

const CTASection = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 cta-gradient" />
      <div className="absolute inset-0 grid-pattern opacity-30" />
      
      {/* Decorative glow */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[150px]" />
      <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-accent/20 rounded-full blur-[130px]" />

      <div className="section-container relative">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 pill-badge mb-6">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Ready to Transform?</span>
          </div>

          {/* Headline */}
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            Let's Build Something
            <br />
            <span className="gradient-text">Extraordinary</span> Together
          </h2>

          {/* Description */}
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10">
            Ready to take your digital presence to the next level? Schedule a free 
            consultation with our experts and discover how we can help you achieve 
            your goals.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button
              asChild
              size="lg"
              className="bg-gradient-primary hover:opacity-90 shadow-glow-blue text-base h-14 px-8"
            >
              <Link to="/contact">
                Get Free Consultation
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-primary/30 hover:bg-primary/10 text-base h-14 px-8"
            >
              <Link to="/portfolio">
                View Our Portfolio
              </Link>
            </Button>
          </div>

          {/* Trust text */}
          <p className="mt-8 text-sm text-muted-foreground">
            ✓ No commitment required &nbsp;&nbsp; ✓ Free strategy session &nbsp;&nbsp; ✓ 24-hour response
          </p>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
