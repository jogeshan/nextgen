import { Building2, ShoppingBag, Stethoscope, GraduationCap, Plane, Landmark, Factory, Utensils } from "lucide-react";

const industries = [
  { icon: Building2, name: "Real Estate", description: "Property listings, virtual tours, lead generation" },
  { icon: ShoppingBag, name: "E-Commerce", description: "Online stores, payment integration, inventory" },
  { icon: Stethoscope, name: "Healthcare", description: "Patient portals, telemedicine, HIPAA compliance" },
  { icon: GraduationCap, name: "Education", description: "LMS platforms, e-learning, student portals" },
  { icon: Plane, name: "Travel & Tourism", description: "Booking systems, itinerary planning, reviews" },
  { icon: Landmark, name: "Finance", description: "Fintech apps, banking solutions, security" },
  { icon: Factory, name: "Manufacturing", description: "Supply chain, inventory, process automation" },
  { icon: Utensils, name: "Food & Beverage", description: "Online ordering, reservations, delivery" },
];

const IndustriesSection = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-accent/5" />

      <div className="section-container relative">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="pill-badge mb-4 inline-block">Industries</span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            Industries We <span className="gradient-text">Serve</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            We bring deep expertise across diverse industries, delivering 
            tailored solutions that address unique sector challenges.
          </p>
        </div>

        {/* Industries Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          {industries.map((industry, index) => (
            <div
              key={index}
              className="group glass-card rounded-xl p-5 sm:p-6 text-center hover:border-primary/30 transition-all cursor-pointer"
            >
              <div className="w-14 h-14 mx-auto rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 group-hover:scale-110 transition-all">
                <industry.icon className="w-7 h-7 text-primary" />
              </div>
              <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors">
                {industry.name}
              </h3>
              <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                {industry.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default IndustriesSection;
