import { ArrowUpRight, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const projects = [
  {
    title: "TechStart Platform",
    category: "Web Development",
    description: "A comprehensive SaaS platform for startup management with real-time analytics.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop",
    stats: ["+300% Traffic", "2x Conversions"],
    tags: ["React", "Node.js", "AWS"],
  },
  {
    title: "GreenLife E-commerce",
    category: "E-Commerce",
    description: "Modern e-commerce platform with AI-powered recommendations and seamless checkout.",
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&h=400&fit=crop",
    stats: ["+450% Sales", "3.5s Load Time"],
    tags: ["Shopify", "SEO", "Marketing"],
  },
  {
    title: "HealthCare Connect",
    category: "Healthcare",
    description: "HIPAA-compliant telemedicine platform connecting patients with healthcare providers.",
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600&h=400&fit=crop",
    stats: ["50K+ Users", "4.9 Rating"],
    tags: ["React", "HIPAA", "Video Chat"],
  },
];

const PortfolioSection = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-muted/10 via-background to-muted/10" />

      <div className="section-container relative">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <span className="pill-badge mb-4 inline-block">Portfolio</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold">
              Featured <span className="gradient-text">Projects</span>
            </h2>
          </div>
          <Button asChild variant="outline" className="border-primary/30 hover:bg-primary/10">
            <Link to="/portfolio">
              View All Projects
              <ArrowUpRight className="ml-2 w-4 h-4" />
            </Link>
          </Button>
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <Link
              key={index}
              to="/portfolio"
              className="group glass-card rounded-2xl overflow-hidden hover:border-primary/30 transition-all"
            >
              {/* Image */}
              <div className="relative h-52 overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
                
                {/* Category badge */}
                <div className="absolute top-4 left-4">
                  <span className="text-xs font-medium px-3 py-1 rounded-full bg-background/80 backdrop-blur-sm">
                    {project.category}
                  </span>
                </div>

                {/* Hover overlay */}
                <div className="absolute inset-0 bg-primary/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <ExternalLink className="w-8 h-8 text-primary-foreground" />
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-lg font-bold mb-2 group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {project.description}
                </p>

                {/* Stats */}
                <div className="flex gap-3 mb-4">
                  {project.stats.map((stat, i) => (
                    <span key={i} className="text-xs font-medium px-2.5 py-1 rounded-full bg-secondary/20 text-secondary">
                      {stat}
                    </span>
                  ))}
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, i) => (
                    <span key={i} className="text-xs text-muted-foreground">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PortfolioSection;
