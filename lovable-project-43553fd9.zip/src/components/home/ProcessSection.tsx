import { MessageSquare, Search, Lightbulb, Code, Rocket, BarChart3 } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: MessageSquare,
    title: "Discovery Call",
    description: "We start with a deep-dive consultation to understand your business, goals, and challenges.",
  },
  {
    number: "02",
    icon: Search,
    title: "Research & Analysis",
    description: "Our team conducts thorough market research and competitive analysis to inform our strategy.",
  },
  {
    number: "03",
    icon: Lightbulb,
    title: "Strategy & Planning",
    description: "We develop a comprehensive roadmap with clear milestones, timelines, and deliverables.",
  },
  {
    number: "04",
    icon: Code,
    title: "Design & Development",
    description: "Our experts bring your vision to life with cutting-edge design and robust development.",
  },
  {
    number: "05",
    icon: Rocket,
    title: "Launch & Deploy",
    description: "We ensure a smooth launch with rigorous testing, optimization, and seamless deployment.",
  },
  {
    number: "06",
    icon: BarChart3,
    title: "Grow & Scale",
    description: "We continue to optimize and scale your digital presence with ongoing support and analytics.",
  },
];

const ProcessSection = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-muted/10 to-background" />
      <div className="absolute inset-0 grid-pattern opacity-20" />

      <div className="section-container relative">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="pill-badge mb-4 inline-block">Our Process</span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            How We <span className="gradient-text">Work</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Our proven methodology ensures consistent delivery of exceptional 
            results, from initial concept to successful launch and beyond.
          </p>
        </div>

        {/* Process Steps */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {steps.map((step, index) => (
            <div
              key={index}
              className="relative group"
            >
              <div className="glass-card rounded-2xl p-6 sm:p-8 h-full hover:border-primary/30 transition-all">
                {/* Step number */}
                <div className="absolute -top-3 -right-3 w-12 h-12 rounded-full bg-gradient-primary flex items-center justify-center shadow-glow-blue">
                  <span className="text-sm font-bold text-primary-foreground">{step.number}</span>
                </div>

                {/* Icon */}
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/20 transition-colors">
                  <step.icon className="w-6 h-6 text-primary" />
                </div>

                {/* Content */}
                <h3 className="text-lg font-bold mb-3 group-hover:text-primary transition-colors">
                  {step.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {step.description}
                </p>
              </div>

              {/* Connector line (hidden on last items) */}
              {index < steps.length - 1 && index !== 2 && (
                <div className="hidden lg:block absolute top-1/2 -right-3 w-6 h-0.5 bg-gradient-to-r from-primary/50 to-transparent" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;
