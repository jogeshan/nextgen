import { Link } from "react-router-dom";
import { ArrowRight, Code, Search, Megaphone, Video, TrendingUp, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";

const services = [
  {
    icon: Code,
    title: "Web Development",
    description: "Custom websites, web apps, and e-commerce solutions built with cutting-edge technologies.",
    features: ["Custom Websites", "Web Applications", "E-commerce", "WordPress"],
    color: "from-primary to-primary-glow",
    href: "/services#web-development",
  },
  {
    icon: Search,
    title: "SEO Services",
    description: "Data-driven SEO strategies that boost your visibility and drive organic traffic.",
    features: ["Technical SEO", "On-Page SEO", "Local SEO", "SEO Audits"],
    color: "from-secondary to-brand-cyan",
    href: "/services#seo",
  },
  {
    icon: TrendingUp,
    title: "Digital Marketing",
    description: "Comprehensive digital marketing campaigns that convert visitors into customers.",
    features: ["PPC Campaigns", "Email Marketing", "Lead Generation", "Analytics"],
    color: "from-accent to-brand-purple",
    href: "/services#digital-marketing",
  },
  {
    icon: Share2,
    title: "Social Media Marketing",
    description: "Strategic social media management that builds your brand and engages your audience.",
    features: ["Content Strategy", "Community Management", "Paid Ads", "Analytics"],
    color: "from-brand-green to-secondary",
    href: "/services#smm",
  },
  {
    icon: Video,
    title: "Video Marketing",
    description: "Compelling video content that tells your story and drives engagement.",
    features: ["Promo Videos", "Product Videos", "YouTube Marketing", "Ads"],
    color: "from-primary to-accent",
    href: "/services#video-marketing",
  },
  {
    icon: Megaphone,
    title: "Brand Strategy",
    description: "Strategic brand development that sets you apart from the competition.",
    features: ["Brand Identity", "Messaging", "Positioning", "Guidelines"],
    color: "from-brand-purple to-primary",
    href: "/services#branding",
  },
];

const ServicesSection = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-muted/20 to-background" />
      <div className="absolute inset-0 dot-pattern opacity-40" />

      <div className="section-container relative">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="pill-badge mb-4 inline-block">Our Services</span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            Solutions That Drive <span className="gradient-text">Results</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            From web development to digital marketing, we offer comprehensive 
            services designed to accelerate your business growth.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <Link
              key={index}
              to={service.href}
              className="group service-card rounded-2xl p-6 sm:p-8"
            >
              {/* Icon */}
              <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${service.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                <service.icon className="w-7 h-7 text-primary-foreground" />
              </div>

              {/* Content */}
              <h3 className="text-xl font-bold mb-3 group-hover:text-primary transition-colors">
                {service.title}
              </h3>
              <p className="text-muted-foreground text-sm mb-5 leading-relaxed">
                {service.description}
              </p>

              {/* Features */}
              <div className="flex flex-wrap gap-2 mb-6">
                {service.features.map((feature, i) => (
                  <span
                    key={i}
                    className="text-xs px-2.5 py-1 rounded-full bg-muted text-muted-foreground"
                  >
                    {feature}
                  </span>
                ))}
              </div>

              {/* Link */}
              <div className="flex items-center gap-2 text-sm font-medium text-primary">
                Learn More
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <Button
            asChild
            size="lg"
            variant="outline"
            className="border-primary/30 hover:bg-primary/10"
          >
            <Link to="/services">
              View All Services
              <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
