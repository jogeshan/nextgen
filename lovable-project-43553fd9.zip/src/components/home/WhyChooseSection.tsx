import { Award, Users, Zap, Shield, HeartHandshake, Lightbulb } from "lucide-react";

const features = [
  {
    icon: Zap,
    title: "Cutting-Edge Tech",
    description: "We leverage the latest technologies and frameworks to build fast, scalable, and future-proof solutions.",
  },
  {
    icon: Users,
    title: "Expert Team",
    description: "Our team of seasoned developers, designers, and strategists bring years of industry experience.",
  },
  {
    icon: Award,
    title: "Proven Results",
    description: "With 500+ successful projects, we have a track record of delivering exceptional outcomes.",
  },
  {
    icon: HeartHandshake,
    title: "Client-Centric",
    description: "Your success is our priority. We work closely with you to understand and exceed your goals.",
  },
  {
    icon: Shield,
    title: "Reliable & Secure",
    description: "We follow industry best practices to ensure your projects are secure and reliable.",
  },
  {
    icon: Lightbulb,
    title: "Innovation First",
    description: "We stay ahead of trends to bring innovative solutions that give you a competitive edge.",
  },
];

const WhyChooseSection = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
      
      {/* Decorative elements */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-primary/10 rounded-full blur-[150px] -translate-y-1/2" />
      <div className="absolute top-1/2 right-0 w-80 h-80 bg-accent/10 rounded-full blur-[130px] -translate-y-1/2" />

      <div className="section-container relative">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left content */}
          <div>
            <span className="pill-badge mb-4 inline-block">Why NexGen</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
              Partner With The <span className="gradient-text">Best</span>
            </h2>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              We don't just build websites or run campaigns—we create digital 
              experiences that transform businesses. Here's why leading companies 
              choose NexGen IT Consulting.
            </p>

            {/* Trust badges */}
            <div className="flex flex-wrap gap-6 items-center">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-primary flex items-center justify-center">
                  <span className="text-xl font-bold text-primary-foreground">5</span>
                </div>
                <div>
                  <div className="font-semibold">⭐ Star Rating</div>
                  <div className="text-sm text-muted-foreground">on Clutch</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-accent flex items-center justify-center">
                  <Award className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <div className="font-semibold">Award Winning</div>
                  <div className="text-sm text-muted-foreground">Agency</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right content - Features grid */}
          <div className="grid sm:grid-cols-2 gap-5">
            {features.map((feature, index) => (
              <div
                key={index}
                className="glass-card rounded-xl p-5 hover:border-primary/30 transition-colors group"
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyChooseSection;
