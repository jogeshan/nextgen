import { Link } from "react-router-dom";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { ArrowRight, Target, Eye, Heart, Users, Lightbulb, Shield, Linkedin, Twitter } from "lucide-react";

const values = [
  { icon: Lightbulb, title: "Innovation", description: "We embrace cutting-edge technologies and creative solutions." },
  { icon: Target, title: "Excellence", description: "We deliver nothing short of exceptional quality in every project." },
  { icon: Heart, title: "Integrity", description: "We build relationships based on transparency and honest communication." },
  { icon: Users, title: "Collaboration", description: "We work as an extension of your team, sharing knowledge and expertise." },
  { icon: Shield, title: "Reliability", description: "We deliver on our promises, on time and within budget." },
  { icon: Eye, title: "Vision", description: "We think long-term, building solutions that grow with your business." },
];

const team = [
  {
    name: "Md Khalid Hossain",
    role: "Founder",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop&crop=face",
    linkedin: "#",
    twitter: "#",
  },
  {
    name: "Md Sohan",
    role: "Lead SEO",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&h=400&fit=crop&crop=face",
    linkedin: "#",
    twitter: "#",
  },
  {
    name: "Shafaet Hossain Abrar",
    role: "Web Developer",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=face",
    linkedin: "#",
    twitter: "#",
  },
  {
    name: "Sakib Hasan Sojib",
    role: "Web Developer",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
    linkedin: "#",
    twitter: "#",
  },
  {
    name: "Md Ahbibur Rahman",
    role: "Content Manager",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
    linkedin: "#",
    twitter: "#",
  },
];

const milestones = [
  { year: "Nov 2024", title: "Founded in the UK", description: "NexGen IT Consulting Ltd was incorporated in the United Kingdom with a vision to deliver world-class digital solutions." },
  { year: "Dec 2024", title: "First Clients Onboarded", description: "Quickly built trust with our first clients, delivering SEO, web development, and content strategies." },
  { year: "Early 2025", title: "Team Expansion", description: "Grew our specialist team to cover SEO, web development, and content management under one roof." },
  { year: "Mid 2025", title: "Growing Portfolio", description: "Expanded our client portfolio across multiple industries, establishing a strong UK and international presence." },
  { year: "2026", title: "Scaling Up", description: "Continuing to grow our services and client base, with a focus on AI-powered digital experiences." },
];

const AboutPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        {/* Hero */}
        <section className="pt-32 pb-20 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
          <div className="section-container relative">
            <div className="max-w-4xl mx-auto text-center">
              <span className="pill-badge mb-4 inline-block">About Us</span>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
                We're Passionate About
                <br />
                <span className="gradient-text">Digital Innovation</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                Founded in November 2024 and incorporated in the United Kingdom, NexGen IT Consulting Ltd 
                is a fast-growing digital agency delivering expert web development, SEO, 
                and content solutions to businesses worldwide.
              </p>
            </div>
          </div>
        </section>

        {/* Mission & Vision */}
        <section className="py-20 relative">
          <div className="section-container">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="glass-card rounded-2xl p-8 sm:p-10">
                <div className="w-14 h-14 rounded-xl bg-gradient-primary flex items-center justify-center mb-6">
                  <Target className="w-7 h-7 text-primary-foreground" />
                </div>
                <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
                <p className="text-muted-foreground leading-relaxed">
                  To empower businesses of all sizes with innovative digital solutions 
                  that drive measurable growth, enhance operational efficiency, and 
                  create lasting competitive advantages in an ever-evolving digital landscape.
                </p>
              </div>
              <div className="glass-card rounded-2xl p-8 sm:p-10">
                <div className="w-14 h-14 rounded-xl bg-gradient-accent flex items-center justify-center mb-6">
                  <Eye className="w-7 h-7 text-primary-foreground" />
                </div>
                <h2 className="text-2xl font-bold mb-4">Our Vision</h2>
                <p className="text-muted-foreground leading-relaxed">
                  To become the world's most trusted IT consulting partner, known for 
                  delivering transformative digital experiences that set new industry 
                  standards and help businesses thrive in the digital age.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Timeline */}
        <section className="py-20 relative">
          <div className="absolute inset-0 bg-gradient-to-b from-muted/10 via-background to-muted/10" />
          <div className="section-container relative">
            <div className="text-center mb-12">
              <span className="pill-badge mb-4 inline-block">Our Journey</span>
              <h2 className="text-3xl sm:text-4xl font-bold">
                Key <span className="gradient-text">Milestones</span>
              </h2>
            </div>
            <div className="max-w-3xl mx-auto space-y-8">
              {milestones.map((milestone, index) => (
                <div key={index} className="flex gap-6 items-start">
                  <div className="flex flex-col items-center">
                    <div className="timeline-dot" />
                    {index < milestones.length - 1 && (
                      <div className="w-0.5 h-full min-h-[60px] bg-gradient-to-b from-primary/50 to-transparent mt-2" />
                    )}
                  </div>
                  <div className="pb-8">
                    <span className="text-sm font-bold text-primary">{milestone.year}</span>
                    <h3 className="text-lg font-bold mt-1 mb-2">{milestone.title}</h3>
                    <p className="text-sm text-muted-foreground">{milestone.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Core Values */}
        <section className="py-20 relative">
          <div className="section-container">
            <div className="text-center mb-12">
              <span className="pill-badge mb-4 inline-block">Core Values</span>
              <h2 className="text-3xl sm:text-4xl font-bold">
                What We <span className="gradient-text">Stand For</span>
              </h2>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {values.map((value, index) => (
                <div key={index} className="glass-card rounded-xl p-6 hover:border-primary/30 transition-all group">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                    <value.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-bold mb-2">{value.title}</h3>
                  <p className="text-sm text-muted-foreground">{value.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Team */}
        <section id="team" className="py-20 relative scroll-mt-24">
          <div className="absolute inset-0 bg-gradient-to-b from-muted/10 via-background to-muted/10" />
          <div className="section-container relative">
            <div className="text-center mb-12">
              <span className="pill-badge mb-4 inline-block">Our Team</span>
              <h2 className="text-3xl sm:text-4xl font-bold">
                Meet the <span className="gradient-text">Experts</span>
              </h2>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
              {team.map((member, index) => (
                <div key={index} className="glass-card rounded-2xl overflow-hidden group hover:border-primary/30 transition-all">
                  <div className="relative h-64 overflow-hidden">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
                  </div>
                  <div className="p-5 text-center">
                    <h3 className="font-bold text-lg">{member.name}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{member.role}</p>
                    <div className="flex justify-center gap-2">
                      <a href={member.linkedin} className="w-8 h-8 rounded-lg bg-muted/50 flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-all" aria-label="LinkedIn">
                        <Linkedin className="w-4 h-4" />
                      </a>
                      <a href={member.twitter} className="w-8 h-8 rounded-lg bg-muted/50 flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-all" aria-label="Twitter">
                        <Twitter className="w-4 h-4" />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-24 relative">
          <div className="absolute inset-0 cta-gradient" />
          <div className="section-container relative text-center">
            <h2 className="text-3xl sm:text-4xl font-bold mb-6">
              Want to Join Our <span className="gradient-text">Team</span>?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              We're always looking for talented people who share our passion for digital innovation.
            </p>
            <Button asChild size="lg" className="bg-gradient-primary hover:opacity-90 shadow-glow-blue h-14 px-8">
              <Link to="/contact">
                Get in Touch <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default AboutPage;
