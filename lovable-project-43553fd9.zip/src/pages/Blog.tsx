import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Link } from "react-router-dom";
import { ArrowRight, Clock, User, Tag } from "lucide-react";

const featuredPost = {
  title: "The Future of Web Development: Trends to Watch in 2026",
  excerpt: "Explore the cutting-edge technologies and methodologies that are reshaping how we build for the web.",
  image: "https://images.unsplash.com/photo-1504639725590-34d0984388bd?w=1200&h=600&fit=crop",
  author: "Alex Rivera",
  date: "March 5, 2026",
  category: "Web Development",
  readTime: "8 min read",
};

const posts = [
  {
    title: "10 SEO Strategies That Actually Work in 2026",
    excerpt: "Discover proven SEO tactics that can help you dominate search rankings and drive organic traffic.",
    image: "https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?w=600&h=400&fit=crop",
    author: "Priya Sharma",
    date: "March 2, 2026",
    category: "SEO",
    readTime: "6 min read",
  },
  {
    title: "How to Build a High-Converting Landing Page",
    excerpt: "Learn the essential elements and design principles that make landing pages convert.",
    image: "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=600&h=400&fit=crop",
    author: "James Walker",
    date: "Feb 28, 2026",
    category: "Marketing",
    readTime: "5 min read",
  },
  {
    title: "Social Media Marketing: A Complete Guide for 2026",
    excerpt: "Everything you need to know about building a successful social media presence this year.",
    image: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=600&h=400&fit=crop",
    author: "Lisa Chen",
    date: "Feb 25, 2026",
    category: "Social Media",
    readTime: "10 min read",
  },
  {
    title: "Why Your Business Needs a Progressive Web App",
    excerpt: "PWAs offer the best of both web and native apps. Here's why you should consider building one.",
    image: "https://images.unsplash.com/photo-1555421689-491a97ff2040?w=600&h=400&fit=crop",
    author: "Alex Rivera",
    date: "Feb 20, 2026",
    category: "Web Development",
    readTime: "7 min read",
  },
  {
    title: "Email Marketing Automation: Getting Started",
    excerpt: "A beginner-friendly guide to setting up automated email campaigns that drive results.",
    image: "https://images.unsplash.com/photo-1596526131083-e8c633c948d2?w=600&h=400&fit=crop",
    author: "James Walker",
    date: "Feb 15, 2026",
    category: "Marketing",
    readTime: "6 min read",
  },
  {
    title: "Video Marketing Statistics You Need to Know",
    excerpt: "Compelling data that proves why video should be a cornerstone of your marketing strategy.",
    image: "https://images.unsplash.com/photo-1492619375914-88005aa9e8fb?w=600&h=400&fit=crop",
    author: "Lisa Chen",
    date: "Feb 10, 2026",
    category: "Video",
    readTime: "4 min read",
  },
];

const categories = ["All", "Web Development", "SEO", "Marketing", "Social Media", "Video"];

const BlogPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        {/* Hero */}
        <section className="pt-32 pb-12 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
          <div className="section-container relative text-center">
            <span className="pill-badge mb-4 inline-block">Blog</span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
              Insights & <span className="gradient-text">Resources</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Expert insights, industry trends, and actionable tips to help you 
              stay ahead in the digital landscape.
            </p>
          </div>
        </section>

        {/* Filter */}
        <section className="py-6">
          <div className="section-container">
            <div className="flex flex-wrap justify-center gap-3">
              {categories.map((cat) => (
                <button
                  key={cat}
                  className={`px-4 py-2 text-sm rounded-full transition-all ${
                    cat === "All"
                      ? "bg-gradient-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Post */}
        <section className="py-8">
          <div className="section-container">
            <div className="glass-card rounded-2xl overflow-hidden group hover:border-primary/30 transition-all">
              <div className="grid md:grid-cols-2">
                <div className="relative h-64 md:h-auto overflow-hidden">
                  <img
                    src={featuredPost.image}
                    alt={featuredPost.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="text-xs font-medium px-3 py-1 rounded-full bg-primary text-primary-foreground">
                      Featured
                    </span>
                  </div>
                </div>
                <div className="p-6 sm:p-10 flex flex-col justify-center">
                  <span className="pill-badge mb-4 inline-block w-fit">{featuredPost.category}</span>
                  <h2 className="text-2xl sm:text-3xl font-bold mb-4 group-hover:text-primary transition-colors">
                    {featuredPost.title}
                  </h2>
                  <p className="text-muted-foreground mb-6">{featuredPost.excerpt}</p>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6">
                    <span className="flex items-center gap-1"><User className="w-3.5 h-3.5" />{featuredPost.author}</span>
                    <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{featuredPost.readTime}</span>
                  </div>
                  <div>
                    <span className="inline-flex items-center gap-1 text-sm font-medium text-primary cursor-pointer">
                      Read Article <ArrowRight className="w-4 h-4" />
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Posts Grid */}
        <section className="py-12 pb-24">
          <div className="section-container">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {posts.map((post, index) => (
                <article
                  key={index}
                  className="group glass-card rounded-2xl overflow-hidden hover:border-primary/30 transition-all cursor-pointer"
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className="text-xs font-medium px-3 py-1 rounded-full bg-background/80 backdrop-blur-sm flex items-center gap-1">
                        <Tag className="w-3 h-3" /> {post.category}
                      </span>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-lg font-bold mb-2 group-hover:text-primary transition-colors line-clamp-2">
                      {post.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><User className="w-3 h-3" />{post.author}</span>
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{post.readTime}</span>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* Newsletter */}
        <section className="py-24 relative">
          <div className="absolute inset-0 cta-gradient" />
          <div className="section-container relative text-center">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Stay <span className="gradient-text">Informed</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Subscribe to our newsletter for the latest insights, tips, and industry updates.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 h-12 px-4 rounded-lg bg-muted border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <button className="h-12 px-6 rounded-lg bg-gradient-primary text-primary-foreground font-medium hover:opacity-90 transition-opacity">
                Subscribe
              </button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default BlogPage;
