import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { ArrowUpRight, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const categories = ["All", "Web Development", "E-Commerce", "SEO", "Marketing", "Healthcare"];

const projects = [
  {
    title: "TechStart SaaS Platform",
    category: "Web Development",
    description: "A comprehensive SaaS platform for startup management with real-time analytics and team collaboration tools.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=500&fit=crop",
    results: ["+300% Traffic", "2x Conversions", "50K Users"],
    tags: ["React", "Node.js", "AWS"],
  },
  {
    title: "GreenLife E-Commerce",
    category: "E-Commerce",
    description: "Modern e-commerce platform with AI-powered recommendations and seamless checkout experience.",
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&h=500&fit=crop",
    results: ["+450% Sales", "3.5s Load Time"],
    tags: ["Shopify", "Custom Theme", "SEO"],
  },
  {
    title: "HealthCare Connect",
    category: "Healthcare",
    description: "HIPAA-compliant telemedicine platform connecting patients with healthcare providers worldwide.",
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&h=500&fit=crop",
    results: ["50K+ Users", "4.9 Rating"],
    tags: ["React", "HIPAA", "Telehealth"],
  },
  {
    title: "FinSecure Banking App",
    category: "Web Development",
    description: "Next-generation banking application with AI-powered fraud detection and biometric authentication.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=500&fit=crop",
    results: ["99.9% Uptime", "2M Transactions"],
    tags: ["FinTech", "Security", "Mobile"],
  },
  {
    title: "EduLearn Platform",
    category: "Web Development",
    description: "Interactive e-learning platform with live classes, progress tracking, and gamification.",
    image: "https://images.unsplash.com/photo-1501504905252-473c47e087f8?w=800&h=500&fit=crop",
    results: ["100K Students", "4.8 Rating"],
    tags: ["EdTech", "React", "Video"],
  },
  {
    title: "TravelBuddy SEO Campaign",
    category: "SEO",
    description: "Comprehensive SEO strategy that catapulted a travel startup to page-one rankings for competitive keywords.",
    image: "https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800&h=500&fit=crop",
    results: ["+800% Organic", "#1 Rankings"],
    tags: ["SEO", "Content", "Link Building"],
  },
];

const PortfolioPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        {/* Hero */}
        <section className="pt-32 pb-12 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
          <div className="section-container relative text-center">
            <span className="pill-badge mb-4 inline-block">Portfolio</span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
              Our <span className="gradient-text">Success Stories</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Explore our portfolio of successful projects across various industries 
              and see the impact we've made for our clients.
            </p>
          </div>
        </section>

        {/* Filter */}
        <section className="py-6">
          <div className="section-container">
            <div className="flex flex-wrap justify-center gap-3">
              {categories.map((cat) => (
                <button
                  key={cat}
                  className={`px-4 py-2 text-sm rounded-full transition-all ${
                    cat === "All"
                      ? "bg-gradient-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Projects Grid */}
        <section className="py-12 pb-24">
          <div className="section-container">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project, index) => (
                <div
                  key={index}
                  className="group glass-card rounded-2xl overflow-hidden hover:border-primary/30 transition-all"
                >
                  <div className="relative h-56 overflow-hidden">
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className="text-xs font-medium px-3 py-1 rounded-full bg-background/80 backdrop-blur-sm">
                        {project.category}
                      </span>
                    </div>
                    <div className="absolute inset-0 bg-primary/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <ExternalLink className="w-8 h-8 text-primary-foreground" />
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-lg font-bold mb-2 group-hover:text-primary transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                      {project.description}
                    </p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.results.map((result, i) => (
                        <span key={i} className="text-xs font-medium px-2.5 py-1 rounded-full bg-secondary/20 text-secondary">
                          {result}
                        </span>
                      ))}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {project.tags.map((tag, i) => (
                        <span key={i} className="text-xs text-muted-foreground">#{tag}</span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-24 relative">
          <div className="absolute inset-0 cta-gradient" />
          <div className="section-container relative text-center">
            <h2 className="text-3xl sm:text-4xl font-bold mb-6">
              Want to Be Our Next <span className="gradient-text">Success Story</span>?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Let's discuss how we can help you achieve similar results for your business.
            </p>
            <Button asChild size="lg" className="bg-gradient-primary hover:opacity-90 shadow-glow-blue h-14 px-8">
              <Link to="/contact">
                Start Your Project <ArrowUpRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default PortfolioPage;
