import { Link } from "react-router-dom";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { ArrowRight, Code, Database, Globe, ShoppingCart, Gauge, Search, MapPin, FileText, LinkIcon, ClipboardCheck, Share2, PenTool, DollarSign, BarChart3, Smartphone, Video, Play, Youtube, Clapperboard, BookOpen, Mail, TrendingUp, Target, MousePointerClick, Zap } from "lucide-react";

const serviceCategories = [
  {
    id: "web-development",
    badge: "Web Development",
    title: "Build Your Digital Foundation",
    description: "We craft high-performance websites and web applications that deliver exceptional user experiences and drive business results.",
    services: [
      { icon: Globe, title: "Custom Websites", description: "Bespoke websites designed to reflect your brand and convert visitors into customers.", benefits: ["Responsive Design", "SEO Optimized", "Fast Performance"] },
      { icon: Code, title: "Web Applications", description: "Powerful web apps built with modern frameworks for complex business requirements.", benefits: ["React / Vue", "Scalable Architecture", "Real-time Features"] },
      { icon: ShoppingCart, title: "E-Commerce Development", description: "Online stores that provide seamless shopping experiences and maximize sales.", benefits: ["Payment Integration", "Inventory Management", "Mobile Optimized"] },
      { icon: Database, title: "WordPress Development", description: "Custom WordPress solutions with flexible content management and extensibility.", benefits: ["Custom Themes", "Plugin Development", "Speed Optimization"] },
      { icon: Gauge, title: "Website Optimization", description: "Performance tuning and optimization to ensure lightning-fast load times.", benefits: ["Core Web Vitals", "Caching Strategy", "Image Optimization"] },
    ],
  },
  {
    id: "seo",
    badge: "SEO Services",
    title: "Dominate Search Rankings",
    description: "Data-driven SEO strategies that increase your visibility, drive qualified traffic, and deliver measurable ROI.",
    services: [
      { icon: Search, title: "Technical SEO", description: "Optimize your site's technical foundation for maximum search engine performance.", benefits: ["Site Architecture", "Schema Markup", "Speed Optimization"] },
      { icon: MapPin, title: "Local SEO", description: "Dominate local search results and attract nearby customers to your business.", benefits: ["Google Business", "Local Citations", "Review Management"] },
      { icon: FileText, title: "On-Page SEO", description: "Content optimization that aligns with search intent and ranking factors.", benefits: ["Keyword Strategy", "Content Optimization", "Internal Linking"] },
      { icon: LinkIcon, title: "Off-Page SEO", description: "Build authority through strategic link building and brand mentions.", benefits: ["Link Building", "Digital PR", "Brand Mentions"] },
      { icon: ClipboardCheck, title: "SEO Audits", description: "Comprehensive site audits that uncover issues and reveal growth opportunities.", benefits: ["Technical Analysis", "Competitor Research", "Action Plan"] },
    ],
  },
  {
    id: "smm",
    badge: "Social Media Marketing",
    title: "Amplify Your Social Presence",
    description: "Strategic social media management that builds community, drives engagement, and generates leads.",
    services: [
      { icon: Share2, title: "Social Strategy", description: "Data-driven social media strategies aligned with your business objectives.", benefits: ["Platform Selection", "Content Calendar", "KPI Tracking"] },
      { icon: PenTool, title: "Content Creation", description: "Engaging visual and written content that resonates with your audience.", benefits: ["Graphic Design", "Copywriting", "Video Content"] },
      { icon: DollarSign, title: "Paid Social Campaigns", description: "Targeted advertising campaigns that reach the right audience at the right time.", benefits: ["Facebook Ads", "Instagram Ads", "LinkedIn Ads"] },
      { icon: BarChart3, title: "Analytics & Reporting", description: "Detailed performance analytics with actionable insights for continuous improvement.", benefits: ["Monthly Reports", "ROI Analysis", "Audience Insights"] },
      { icon: Smartphone, title: "Platform Management", description: "Full-service management across all major social media platforms.", benefits: ["Community Management", "Reputation Monitoring", "Engagement"] },
    ],
  },
  {
    id: "video-marketing",
    badge: "Video Marketing",
    title: "Tell Your Story Visually",
    description: "Compelling video content that captivates audiences, builds trust, and drives measurable results.",
    services: [
      { icon: Video, title: "Promotional Videos", description: "Professional promotional videos that showcase your brand's value proposition.", benefits: ["Brand Videos", "Corporate Films", "Event Coverage"] },
      { icon: Play, title: "Product Videos", description: "Engaging product demonstrations and explainer videos that drive conversions.", benefits: ["Demo Videos", "Tutorials", "Unboxing"] },
      { icon: Youtube, title: "YouTube Marketing", description: "YouTube channel management and optimization for maximum reach and engagement.", benefits: ["Channel Strategy", "Video SEO", "Thumbnail Design"] },
      { icon: Clapperboard, title: "Social Video Ads", description: "Scroll-stopping video advertisements optimized for social media platforms.", benefits: ["Short-form Content", "Reels & TikTok", "Story Ads"] },
      { icon: BookOpen, title: "Brand Storytelling", description: "Authentic brand stories that connect emotionally with your target audience.", benefits: ["Documentary Style", "Customer Stories", "Origin Stories"] },
    ],
  },
  {
    id: "digital-marketing",
    badge: "Digital Marketing",
    title: "Maximize Your ROI",
    description: "Comprehensive digital marketing strategies that attract, engage, and convert your ideal customers.",
    services: [
      { icon: MousePointerClick, title: "PPC Advertising", description: "Pay-per-click campaigns that deliver immediate visibility and qualified leads.", benefits: ["Google Ads", "Bing Ads", "Display Network"] },
      { icon: Target, title: "Lead Generation", description: "Multi-channel lead generation strategies that fill your sales pipeline.", benefits: ["Landing Pages", "Lead Magnets", "Nurture Sequences"] },
      { icon: TrendingUp, title: "Conversion Optimization", description: "Data-driven CRO strategies that turn more visitors into paying customers.", benefits: ["A/B Testing", "UX Analysis", "Funnel Optimization"] },
      { icon: Mail, title: "Email Marketing", description: "Targeted email campaigns that nurture relationships and drive repeat business.", benefits: ["Automation", "Segmentation", "Drip Campaigns"] },
      { icon: Zap, title: "Marketing Automation", description: "Streamline your marketing with intelligent automation workflows.", benefits: ["HubSpot", "Workflow Design", "Lead Scoring"] },
    ],
  },
];

const ServicesPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        {/* Hero */}
        <section className="pt-32 pb-20 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent" />
          <div className="absolute inset-0 grid-pattern opacity-30" />
          <div className="section-container relative text-center">
            <span className="pill-badge mb-4 inline-block">Our Services</span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
              Comprehensive <span className="gradient-text">Digital Solutions</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              From web development to digital marketing, we provide end-to-end services 
              that help businesses grow, compete, and succeed in the digital landscape.
            </p>
          </div>
        </section>

        {/* Service Categories */}
        {serviceCategories.map((category, catIndex) => (
          <section key={catIndex} id={category.id} className="py-20 relative scroll-mt-24">
            {catIndex % 2 === 0 && (
              <div className="absolute inset-0 bg-gradient-to-b from-muted/10 via-background to-muted/10" />
            )}
            <div className="section-container relative">
              {/* Category Header */}
              <div className="mb-12">
                <span className="pill-badge mb-4 inline-block">{category.badge}</span>
                <h2 className="text-3xl sm:text-4xl font-bold mb-4">
                  {category.title}
                </h2>
                <p className="text-lg text-muted-foreground max-w-3xl">
                  {category.description}
                </p>
              </div>

              {/* Services Grid */}
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {category.services.map((service, index) => (
                  <div
                    key={index}
                    className="service-card rounded-2xl p-6 sm:p-8"
                  >
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5">
                      <service.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-lg font-bold mb-3">{service.title}</h3>
                    <p className="text-sm text-muted-foreground mb-5 leading-relaxed">
                      {service.description}
                    </p>
                    <div className="flex flex-wrap gap-2 mb-5">
                      {service.benefits.map((benefit, i) => (
                        <span key={i} className="text-xs px-2.5 py-1 rounded-full bg-muted text-muted-foreground">
                          {benefit}
                        </span>
                      ))}
                    </div>
                    <Button asChild variant="outline" size="sm" className="border-primary/30 hover:bg-primary/10">
                      <Link to="/contact">
                        Get Started <ArrowRight className="ml-1 w-3 h-3" />
                      </Link>
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </section>
        ))}

        {/* CTA */}
        <section className="py-24 relative">
          <div className="absolute inset-0 cta-gradient" />
          <div className="section-container relative text-center">
            <h2 className="text-3xl sm:text-4xl font-bold mb-6">
              Need a Custom <span className="gradient-text">Solution</span>?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Every business is unique. Let's discuss how we can tailor our services 
              to meet your specific needs and objectives.
            </p>
            <Button asChild size="lg" className="bg-gradient-primary hover:opacity-90 shadow-glow-blue h-14 px-8">
              <Link to="/contact">
                Schedule a Consultation <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default ServicesPage;
